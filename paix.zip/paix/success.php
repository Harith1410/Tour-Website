<?php
require "../db.php";
$ref = $_GET['ref'] ?? '';

$stmt = $conn->prepare("SELECT * FROM payments WHERE reference_no=?");
$stmt->bind_param("s", $ref);
$stmt->execute();
$result = $stmt->get_result();
$payment = $result->fetch_assoc();
?>

<h2>Payment <?= htmlspecialchars($payment['status']) ?></h2>
<p>Reference: <b><?= htmlspecialchars($payment['reference_no']) ?></b></p>
<p>Amount: <?= number_format($payment['amount'],2) ?> TZS</p>
<p>Payment Method: <?= htmlspecialchars($payment['payment_method']) ?></p>
<a href="../index.php">Back to Home</a>
