-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2026 at 11:04 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `paix_tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `FullName` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Date` datetime NOT NULL,
  `Destination` varchar(50) NOT NULL,
  `Request` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `FullName`, `Email`, `Date`, `Destination`, `Request`, `created_at`) VALUES
(1, 'Harith Hashim Hamza', 'harithhamza24@gmail.com', '2026-09-27 10:24:00', 'Tanzania', 'jjjjj', '2026-09-27 06:24:48'),
(2, 'Hamza juma Ali', 'paixprivatetour@gmail.com', '2026-09-27 11:25:00', 'Zanzibar', 'hjhiuefguo;gfriugigfdg7p9regi', '2026-09-27 06:25:48'),
(3, 'Harith Hm Hamza', 'harithhamza24@gmail.com', '2026-09-27 00:00:00', 'Zanzibar', 'lmjiggo87yfv', '2026-09-27 06:58:47'),
(4, 'Hamza juma Ali', 'paixprivatetour@gmail.com', '2026-09-30 00:00:00', 'Zanzibar', 'heheheheehe', '2026-09-28 05:53:56'),
(5, 'Harith Hashim Hamza', 'harithhamza24@gmail.com', '2026-09-29 16:44:00', 'Tanzania', 'hkgydud,j', '2026-09-29 08:44:46'),
(6, 'Harith Hashim Hamza', 'harithhamza24@gmail.com', '2026-09-30 17:26:00', 'Zanzibar', 'good', '2026-09-30 11:26:48');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `booking_id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, NULL, 'Harith Hamza', 'paixprivatetour@gmail.com', 'hhhhh', 'jiogyudtdslk.gudsywkuyfiuew56sytkvls6azkst4rjazdxaskls.dydyj5swy5ei.krd', '2026-09-27 06:44:16'),
(2, NULL, 'Harith Hamza', 'paixprivatetour@gmail.com', 'hhhhh', 'mjioh', '2026-09-27 06:58:06'),
(3, NULL, 'Harith Hamza', 'paixprivatetour@gmail.com', 'hhhhh', 'mnm', '2026-09-30 11:30:43'),
(4, NULL, 'Harith Hamza', 'paixprivatetour@gmail.com', 'hhhhh', 'jbgygliy', '2026-09-30 11:33:27'),
(5, NULL, 'Harith Hamza', 'harithhamza24@gmail.com', 'hhhhh', 'bhjbih', '2026-09-30 11:34:20');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subscribed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `subscribed_at`) VALUES
(1, 'harithhamza24@gmail.com', '2026-10-01 07:29:45'),
(2, 'jj@gmail.com', '2026-10-01 07:30:03'),
(3, 'hhh@gmail.com', '2026-10-01 07:31:09'),
(4, 'hh@gmail.com', '2026-10-01 07:32:06'),
(5, 'hamad@gmail.com', '2026-10-01 07:34:28'),
(6, 'haji@gmail.com', '2026-10-01 07:34:54'),
(7, 'paixprivatetour@gmail.com', '2026-10-01 07:41:45'),
(8, 'halid@gmail.com', '2026-10-01 07:42:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_contact_booking` (`booking_id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `fk_contact_booking` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
