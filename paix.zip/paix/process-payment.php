<?php
require "db.php";
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $paymentType   = $_POST['paymentType'] ?? '';
    $bankName      = $_POST['bankName'] ?? null;
    $accountNumber = $_POST['accountNumber'] ?? null;
    $amount        = $_POST['amount'] ?? '';

    // Validate required fields
    if (empty($paymentType) || empty($amount)) {
        echo json_encode([
            "status" => "error",
            "message" => "Payment type and amount are required."
        ]);
        exit;
    }

    // Insert into database
    $sql = "INSERT INTO payments (payment_type, bank_name, account_number, amount)
            VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        echo json_encode([
            "status" => "error",
            "message" => "Database error. Try again."
        ]);
        exit;
    }

    $stmt->bind_param("sssd", $paymentType, $bankName, $accountNumber, $amount);

    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Payment sent successfully!"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to send payment."
        ]);
    }

    $stmt->close();
    $conn->close();
}

