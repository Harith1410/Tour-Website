<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Paix Tour</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>Unguja Zanzibar, Tanzania</small>
                    <small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+255 624 656 6618 /+255 773 808 769</small>
                    <small class="text-light"><i class="fa fa-envelope-open me-2"></i>PaixprivateTour@gmail.com</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-facebook-f fw-normal"></i></a> 
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar & Hero Start -->
    <div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
            <a href="" class="navbar-brand p-0">
                <h1 class="text-primary m-0"><img src="img/h2.png" alt="Logo"></i>Paix Tour</h1> 
            </a>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link">About</a>
                    <a href="service.php" class="nav-item nav-link active">Services</a>
                    <a href="package.php" class="nav-item nav-link">Packages</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu m-0">
                            <a href="Tanzania.php" class="dropdown-item">Tanzania</a>
                            <a href="zanzibar.php" class="dropdown-item">zanzibar</a>
                        </div>
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
                <a href="booking.php" class="btn btn-primary rounded-pill py-2 px-4">Book Now</a>
            </div>
        </nav>

        <div class="container-fluid bg-primary py-5 mb-5 hero-header">
            <div class="container py-5">
                <div class="row justify-content-center py-5">
                    <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                        <h1 class="display-3 text-white animated slideInDown">Zanzibar</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item"><a href="service.php">Service</a></li>
                                <li class="breadcrumb-item text-white active" aria-current="page">Destination</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar & Hero End -->



     <!-- About Start -->
     <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <!-- <img class="img-fluid position-absolute w-100 h-100" src="img/Zanzibar_Island_.jpg" alt="" style="object-fit: cover;"> -->
                        <video width="100%" height="100%" autoplay muted loop>
                            <source src="img/znz.mp4" type="video/mp4">
                            <source src="tz.mp4" type="video/mp4">
                          Your browser does not support the video tag.
                          </video>
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">Zanzibar</h6>
                    <h1 class="mb-4">What makess<span class="text-primary"> Zanzibar special?</span></h1>
                    <p class="mb-4">The famous islands of the Zanzibar archipelago are located about 25 miles off Dar es Salaam on the mainland coast of Tanzania.</p>
                    <p class="mb-4">What makes Zanzibar different to other tropical island destinations is the eclectic mix of sun, sea, sand and spice. But there is much more - vivid history, culture and a variety of excursions that makes this one of the most popular all-round beach destinations for people of all ages and interests. Apart from this, a whole range of endangered species can be found in the warm tropical waters around the archipelago - from bottlenose dolphins and green turtles to the once assumed extinct coelecanth! Zanzibar also hosts annual festivals and events drawing people from all over East Africa and the world.</p>
                    <h1 class="mb-4">The Best <span class="text-primary"> Beaches in Zanzibar</span></h1>
                    <p class="mb-4"> Zanzibar is renowned for its picturesque white sand beaches and mesmerizing coral reefs in crystal clear waters. The</p>
                    <p class="mb-4"> archipelago, comprising of Unguja and Pemba, both offer unique experiences. Unguja is renowned for its beaches, resorts, and the historic Stone Town, while Pemba, also known as “The Green Island”, is known for its spice production and untouched dive sites.</p>
                    <p class="mb-4"> Whether you’re looking for a relaxing beach vacation or an adventurous dive trip, Zanzibar has something for everyone.</p>
                    
                    <!-- <a class="btn btn-primary py-3 px-5 mt-2" href="">Read More</a> -->
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->
    
    <!-- Testimonial Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="section-title bg-white text-center text-primary px-3">Beaches</h6>
                <h1 class="mb-5">Some of the Best Beach in Zanzibar</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/kizimkazi.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Kizimkazi</h5>
                    <p>Travel Guide</p>
                    <p class="mb-0">Kizimkazi boast stunning beaches with crystal-clear turquoise waters and powdery white sand. These unspoiled stretches of shoreline offer the perfect backdrop for relaxation and rejuvenation. Come for some sunbathing, swimming, or beachcombing.</p>
                    <p>These areas are renowned for their diverse marine life, including vibrant coral reefs, dolphins, turtles, and an array of exotic fish species, making them great diving and snorkeling spots. </p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/uroa pongwe.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Uroa and Pongwe</h5>
                    <p>Beach</p>
                    <p class="mt-2 mb-0">Uroa and Pongwe are neighboring villages that exude that classic Zanzibari coastal charm. They are quiet destinations, and do not offer as much in the way of activities as other spots on the island, but Uroa and Pongwe are very charming and relaxing with some excellent accommodations, providing an ideal retreat from the bustling world.</p>
                    <p>On top of what is immediately available in Uroa and Pongwe, the small size of Zanzibar Island means it is never far to travel to see everything the island and surrounding waters have to offer.</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/jambian.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Jambian</h5>
                    <p>Beach Travel</p>
                    <p class="mt-2 mb-0">The primary attraction of Jambiani Beach is its idyllic beaches, which are considered some of the most beautiful in Zanzibar. With powdery white sand and the calm, warm waters of the Indian Ocean, the beach creates a serene and tranquil atmosphere, inviting visitors to unwind and soak up the sun.</p>
                    <p>Jambiani is also renowned for its rich local culture in this authentic Swahili fishing village. Chat with friendly locals, observe traditional fishing techniques, visit local markets, and enjoy delicious Swahili cuisine.</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/kiwengwa.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Kiwengwa Beach</h5>
                    <p class="mt-2 mb-0">Both Kiwengwa and Pwani Changani boast pristine white sandy beaches that are perfect for relaxation and sunbathing. The turquoise waters of the Indian Ocean provide a beautiful backdrop, and you can take leisurely walks along the shore or get into some water activities.</p>
                    <p>Come here for a quiet getaway away from the more touristic areas of Zanzibar, and enjoy everything the local nature and culture has to offer. </p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/kendwa.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Kendwa Beach</h5>
                    <p class="mt-2 mb-0">You will find a quieter atmosphere just south on Kendwa Beach, the “little sister” of Nungwi. But still, when the sun drops below the horizon after one of Kendwa’s stunning sunsets, this beach also bursts into life with its chill beach parties.</p>
                    <p>The crystal waters here are absolutely perfect for swimming, snorkeling, and diving during the day. You can even spot some colorful starfish just offshore!</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/bb.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Michamvi Beach</h5>
                    <p class="mt-2 mb-0">The Michamvi peninsula on the central east coast of Zimbabwe’s main island has vast stretches of beautiful empty beach to explore and escape from the hustle and bustle of the city. There are 2 large luxury resorts nearby, yet it still feels remote, and beach-goers can definitely find peace by the splashing shores.</p>
                    <p>The eastern side of the peninsula looks out onto a vibrant coral lagoon from palm-lined beaches set in scenic coves among high coral cliffs, while the western side looks out over the serene crystal-blue waters of Chwaka Bay.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->
        

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Company</h4>
                    <a class="btn btn-link" href="about.php">About Us</a>
                    <a class="btn btn-link" href="contact.php">Contact Us</a>
                    <a class="btn btn-link" href="">Privacy Policy</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">FAQs & Help</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Unguja, Zanzibar, Tanzania</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+255 624 656 618</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>paixprivatetour@gmail.com</p>
                    <div class="d-flex pt-2">
                        <!-- <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/profile.php?id=100089488801328"><i class="fab fa-facebook-f fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/@paixprivatetour"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Gallery</h4>
                    <div class="row g-2 pt-2">
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/hh.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/mnemba 22.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/Safari.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/prison.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/serengeti.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/pree.jpg" alt="">
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Newsletter</h4>
                    <p>Subscribe to our newsletter</p>
                     <form id="newsletter-form" action="https://formspree.io/f/mjgpdqvo" method="POST" class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-primary w-100 py-3 ps-4 pe-5" type="email" name="email" placeholder="Your email" aria-label="Your email" required>
                        <button type="submit" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">Subscribe</button>
                    </form>
                    <script>
                    document.getElementById('newsletter-form').addEventListener('submit', async function (event) {
                        event.preventDefault();
                        const form = this;
                        const subscribedEmail = form.elements.email.value;
                        const formData = new FormData(form);

                        try {
                            const [emailResponse, databaseResponse] = await Promise.all([
                                fetch(form.action, {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                }),
                                fetch('subribe.php', {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                })
                            ]);

                            const [emailResult, databaseResult] = await Promise.all([
                                emailResponse.json(),
                                databaseResponse.json()
                            ]);

                            if (!emailResponse.ok || emailResult.ok === false || emailResult.success === false) {
                                const formspreeError = emailResult.errors && emailResult.errors[0] && emailResult.errors[0].message;
                                throw new Error(formspreeError || emailResult.message || 'Could not send the subscription email.');
                            }

                            if (!databaseResponse.ok || !databaseResult.success) {
                                throw new Error(databaseResult.message || 'Could not save the subscription to the database.');
                            }

                            Swal.fire({
                                title: 'Data sent successfully',
                                text: `Your subscription email was sent for ${subscribedEmail}.`,
                                icon: 'success'
                            });
                            form.reset();
                        } catch (error) {
                            Swal.fire('Could not subscribe', error.message || 'Please try again later.', 'error');
                        }
                    });
                    </script>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">Paix Tour</a>, All Right Reserved.
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.php">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>