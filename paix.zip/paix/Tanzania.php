<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Paix Tour</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>Unguja Zanzibar, Tanzania</small>
                    <small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+255 624 656 6618 /+255 773 808 769</small>
                    <small class="text-light"><i class="fa fa-envelope-open me-2"></i>PaixprivateTour@gmail.com</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href=""><i class="fab fa-facebook-f fw-normal"></i></a> 
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar & Hero Start -->
    <div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
            <a href="" class="navbar-brand p-0">
                <h1 class="text-primary m-0"><img src="img/h2.png" alt="Logo"></i>Paix Tour</h1>
            </a>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link">About</a>
                    <a href="service.php" class="nav-item nav-link active">Services</a>
                    <a href="package.php" class="nav-item nav-link">Packages</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu m-0">
                            <a href="Tanzania.php" class="dropdown-item">Tanzania</a>
                            <a href="zanzibar.php" class="dropdown-item">zanzibar</a>
                        </div>
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
                <a href="booking.php" class="btn btn-primary rounded-pill py-2 px-4">Book Now</a>
            </div>
        </nav>

        <div class="container-fluid bg-primary py-5 mb-5 hero-header">
            <div class="container py-5">
                <div class="row justify-content-center py-5">
                    <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                        <h1 class="display-3 text-white animated slideInDown">Tanzania</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item"><a href="#">Pages</a></li>
                                <li class="breadcrumb-item text-white active" aria-current="page">Services</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar & Hero End -->


    <!-- About Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100%">
                        <video width="100%" height="100%" autoplay muted loop>
                            <source src="img/tan.mp4" type="video/mp4">
                            <source src="tz.mp4" type="video/mp4">
                          Your browser does not support the video tag.
                          </video>
                          
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">Tanzania</h6>
                    <p class="mb-4">A real natural paradise located on the east coast of Africa.</p>
                    <h1 class="mb-4">What makes<span class="text-primary"> Tanzania special?</span></h1>
                    <p class="mb-4">Tanzania is one of the top safari destinations in Africa. Tanzania's vast Serengeti National Park is the scene of the annual Great Migration, a breathtaking wildlife spectacle that every serious safari enthusiast should experience at least once in a lifetime. Equally unique is the famous Ngorongoro Crater, home to unparalleled numbers of wild animals. It is easy to combine a safari in northern Tanzania with a tropical beach holiday on Zanzibar. And for the serious traveller, the wild and remote southern region offers beautiful national parks which are relatively untouched by development and human settlement, with huge game reserves such as Selous Game Reserve and Ruaha National Park.</p>
                    <h1 class="mb-4"> What you<span class="text-primary">will find?</span></h1>
                    <p class="mb-4">Broadly speaking, Tanzania as a safari destination can be divided into the more popular Northern Safari Circuit and less crowded Southern Safari Circuit. In addition to this, the remote western part of Tanzania offers something different for the adventurous safari enthusiast and the coastal region is a popular addition to end off a safari in Tanzania with some beach time.</p>
                    <h1 class="mb-4">What to <span class="text-primary">the pack</span></h1>
                    <p class="mb-4">Unless you have a special event to attend, formal clothing is not necessary, and can even be burdensome while in Tanzania. Loose fitting garments that can be worn in layers will ensure your comfort day and night, and you should bring only clothing that you do not mind getting soiled. Stick to neutral or khaki colors and avoid wearing dark blue or black clothes as these colors tend to attract tsetse flies. Wide brimmed hats, sunglasses, sunscreen, insect repellent are a necessity.</p>
                    <h1 class="mb-4"> Climate and<span class="text-primary"> weather</span></h1>
                    <p class="mb-4"> Tanzania is situated in the tropics and most of the country is warm to hot during the dry season, and warm and humid during the wet season. The highlands and areas at altitude (such as the Ngorongoro Crater rim) can be surprisingly cold though. There are generally two wet seasons; the short rains from late October into December, and the long rains from March to May. April is the wettest month.</p>
                    <p class="mb-4"> Many remote lodges close during the rainy season as roads become impassable. The peak season for most safari destinations is the dry season from June to October. During this time where you are most likely to find the migration.</p>
                    
                    <!-- <a class="btn btn-primary py-3 px-5 mt-2" href="">Read More</a> -->
                </div>
            </div>
        </div>
    </div>
    <!-- About End -->
    
    <!-- Testimonial Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="text-center">
                <h6 class="section-title bg-white text-center text-primary px-3">Beaches</h6>
                <h1 class="mb-5">Our safaris</h1>
            </div>
            <div class="owl-carousel testimonial-carousel position-relative">
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/safari 3.jpeg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">North Tanzania</h5>
                    <p class="mb-0">Safari in North Tanzania means tour through different national parks, to discover wildlife and millennial cultures. Try not to get fascinated by amazing sunsets and endless prairies. Experience the thrill of a close encounter with the Big Fives and much more Discover it with us!</p>
                    <h5><p>Everything stars from Arusha</p></h5>
                    <p>Arusha is a city in north eastern Tanzania and the capital of the Arusha Region. Located below Mount Meru, the city is close to the most important Tanzanian parks, Serengeti National Park, Ngorongoro Conservation Area, Lake Manyara National Park, Olduvai Gorge, Tarangire National Park, Mount Kilimanjaro and Mount Meru in the Arusha National Park and is thus considered the safari capital of the world.</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/Safari.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Tarangine National Park</h5>
                    <p class="mt-2 mb-0">Tarangire National Park is a national park in Tanzania's Manyara Region. The name of the park originates from the Tarangire River that crosses the park. The Tarangire River is the primary source of fresh water for wild animals in the Tarangire Ecosystem during the annual dry season.</p>
                    <p>The Tarangire Ecosystem is defined by the long-distance migration of wildebeest and zebras. During the dry season thousands of animals concentrate in Tarangire National Park from the surrounding wet-season dispersal and calving areas.</p>
                    <h5><p>Maweninga Camp</p></h5> 
                     <p>Perched on the top of an imposing granite rock, this camp has the privilege of being within the Tarangire National Park, overlooking Lake Manyara and Burunge.</p>
                     <p>The picturesque backdrop on the horizon are the volcanoes of the Ngorongoro Conservation Area such as the Ngorongoro Crater, Oldeani or Lemagrut ... Built to the highest eco-friendly standards, Maweninga has a particularly low-carbon footprint.</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/gera.jfif" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Saadani</h5>
                    <p class="mt-2 mb-0">Saadani is where the beach meets the bush. The only wildlife sanctuary in East Africa to boast for an Indian Ocean beachfront, it as well possesses all the attributes that make Tanzania’s tropical coastline and islands very popular with European sun-worshipers. Yet it is also the one place where those idle hours of sunbathing might be interrupted by an elephant strolling past, or a lion coming to drink at the nearby waterhole!</p>
                    <h5><p>Saadani National Park</p></h5>
                    <p>Located in the centre of the historic triangle of Bagamoyo, Pangani and Zanzibar, Saadani National Park is the only wildlife sanctuary in Tanzania bordering the ocean. Unlike as in other national parks in Tanzania, here visitors can combine a safari with a relaxing beach stay.</p>
                    <p>Game viewing varies throughout the year and the area is known for sightings of porcupines, civets, bush pigs, baboons and vervet monkeys. On the open sea, you might be able to spot many species of fish, dolphins, turtles and humpback whales. Key wildlife include hippos, crocodiles, lions, buffalo, elephant, giraffe, zebra, dolphins, Zanzibar galago, blue monkey, yellow baboon, hyena, leopard, civet and sable antelope.</p>
                </div>
                <div class="testimonial-item bg-white text-center border p-4">
                    <img class="img-fluid" src="img/seregent.jpg" style="width: 100%; height: 100%;" alt="">
                    <h5 class="mb-0">Serengeti National Park</h5>
                    <p class="mt-2 mb-0">It is no secret that the great annual wildebeest migration in Tanzania's Serengeti National Park is among the most spectacular safari experiences out there. The sheer number of animals (over a million wildebeest, not to mention thousands of zebras and large numbers of other animals), the beauty and vastness of the land, the abundance of predators and predator-prey interaction, all combine to make the Serengeti arguably the top safari destination in the world.</p>
                    <p>The Great Migration is a seasonal affair but there are also areas such as the central Seronera area which are great for game viewing all year round and have plenty of resident wildlife. The Serengeti is Tanzania's flagship national park and one of the best safari destinations in the world. A minimum of three nights is recommended to make the most of the Serengeti, and the ideal would be to stay six nights, in two different areas of the park.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonial End -->
        

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Company</h4>
                    <a class="btn btn-link" href="about.php">About Us</a>
                    <a class="btn btn-link" href="contact.php">Contact Us</a>
                    <a class="btn btn-link" href="service.php">Services</a>
                    <a class="btn btn-link" href="package.php">Packages</a>
                    <a class="btn btn-link" href="about.php">FAQs & Help</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Unguja, Zanzibar, Tanzania</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+255 624 656 618</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>Paixprivatetour@gmail.com</p>
                    <div class="d-flex pt-2">
                        <!-- <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/profile.php?id=100089488801328"><i class="fab fa-facebook-f fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/@paixprivatetour"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Gallery</h4>
                    <div class="row g-2 pt-2">
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/hh.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/mnemba 22.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/Safari.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/prison.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/serengeti.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/pree.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Newsletter</h4>
                    <p>Subscribe to our newsletter.</p>
                     <form id="newsletter-form" action="https://formspree.io/f/mjgpdqvo" method="POST" class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-primary w-100 py-3 ps-4 pe-5" type="email" name="email" placeholder="Your email" aria-label="Your email" required>
                        <button type="submit" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">Subscribe</button>
                    </form>
                    <script>
                    document.getElementById('newsletter-form').addEventListener('submit', async function (event) {
                        event.preventDefault();
                        const form = this;
                        const subscribedEmail = form.elements.email.value;
                        const formData = new FormData(form);

                        try {
                            const [emailResponse, databaseResponse] = await Promise.all([
                                fetch(form.action, {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                }),
                                fetch('subribe.php', {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                })
                            ]);

                            const [emailResult, databaseResult] = await Promise.all([
                                emailResponse.json(),
                                databaseResponse.json()
                            ]);

                            if (!emailResponse.ok || emailResult.ok === false || emailResult.success === false) {
                                const formspreeError = emailResult.errors && emailResult.errors[0] && emailResult.errors[0].message;
                                throw new Error(formspreeError || emailResult.message || 'Could not send the subscription email.');
                            }

                            if (!databaseResponse.ok || !databaseResult.success) {
                                throw new Error(databaseResult.message || 'Could not save the subscription to the database.');
                            }

                            Swal.fire({
                                title: 'Data sent successfully',
                                text: `Your subscription email was sent for ${subscribedEmail}.`,
                                icon: 'success'
                            });
                            form.reset();
                        } catch (error) {
                            Swal.fire('Could not subscribe', error.message || 'Please try again later.', 'error');
                        }
                    });
                    </script>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="">Paix Tour </a>, All Right Reserved.
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.php">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>