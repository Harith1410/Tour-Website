(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();


    // Sticky Navbar
    $(window).scroll(function () {
        if ($(this).scrollTop() > 45) {
            $('.navbar').addClass('sticky-top shadow-sm');
        } else {
            $('.navbar').removeClass('sticky-top shadow-sm');
        }
    });
    
    
    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";
    
    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    function loadSweetAlert() {
        if (window.Swal) {
            return Promise.resolve();
        }

        return new Promise(function (resolve, reject) {
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/sweetalert2@11';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    async function showNewsletterPopup(title, message, icon) {
        try {
            await loadSweetAlert();
            window.Swal.fire({title: title, text: message, icon: icon});
        } catch (error) {
            window.alert(`${title}\n\n${message}`);
        }
    }

    document.querySelectorAll('.newsletter-form').forEach(function (form) {
        form.addEventListener('submit', async function (event) {
            event.preventDefault();

            const email = form.elements.email.value;
            const submitButton = form.querySelector('[type="submit"]');
            submitButton.disabled = true;

            try {
                const formData = new FormData(form);
                const [emailResponse, databaseResponse] = await Promise.all([
                    fetch(form.action, {
                        method: 'POST',
                        body: formData,
                        headers: {'Accept': 'application/json'}
                    }),
                    fetch('subribe.php', {
                        method: 'POST',
                        body: formData,
                        headers: {'Accept': 'application/json'}
                    })
                ]);
                const [emailResult, databaseResult] = await Promise.all([
                    emailResponse.json(),
                    databaseResponse.json()
                ]);

                if (!emailResponse.ok || emailResult.ok === false || emailResult.success === false) {
                    const formspreeError = emailResult.errors && emailResult.errors[0] && emailResult.errors[0].message;
                    throw new Error(formspreeError || emailResult.message || 'Could not send the subscription email.');
                }

                if (!databaseResponse.ok || !databaseResult.success) {
                    throw new Error(databaseResult.message || 'Could not save the subscription to the database.');
                }

                await showNewsletterPopup(
                    'Data sent successfully',
                    `Your subscription was emailed and saved to the database for ${email}.`,
                    'success'
                );
                form.reset();
            } catch (error) {
                const message = error.message || 'Please try again later.';
                await showNewsletterPopup('Could not subscribe', message, 'error');
            } finally {
                submitButton.disabled = false;
            }
        });
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        center: true,
        margin: 24,
        dots: true,
        loop: true,
        nav : false,
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            },
            992:{
                items:3
            }
        }
    });
    
})(jQuery);

