<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Paix Tour</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>Unguja Zanzibar, Tanzania</small>
                    <small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+255 624 656 6618 /+255 785 088 144</small>
                    <small class="text-light"><i class="fa fa-envelope-open me-2"></i>PaixprivateTour@gmail.com</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.youtube.com/@paixprivatetour" target="_blank"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.facebook.com/profile.php?id=100089488801328"><i class="fab fa-facebook-f fw-normal"></i></a> 
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar & Hero Start -->
    <div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
            <a href="" class="navbar-brand p-0">
                <h1 class="text-primary m-0"><img src="img/h2.png" alt="Logo"></i>Paixprivate Tour</h1>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link">About</a>
                    <a href="service.php" class="nav-item nav-link">Services</a>
                    <a href="package.php" class="nav-item nav-link">Packages</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu m-0">
                            <a href="destination.php" class="dropdown-item">Destination</a>
                            <a href="booking.php" class="dropdown-item">Booking</a>
                            <a href="3 Days.php" class="dropdown-item">3 Days</a>
                            <a href="6 Days.php" class="dropdown-item">6 Days</a>
                            <a href="10 Days.php" class="dropdown-item">10 Days</a>
                        </div>
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
                <a href="booking.php" class="btn btn-primary rounded-pill py-2 px-4">Register</a>
            </div>
        </nav>

        <div class="container-fluid bg-primary py-5 mb-5 hero-header">
            <div class="container py-5">
                <div class="row justify-content-center py-5">
                    <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                        <h1 class="display-3 text-white animated slideInDown">ZANZIBAR PACKAGE 6DAYS/7 NIGHTS,HALF BOARD</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item"><a href="package.php">Package</a></li>
                                <li class="breadcrumb-item text-white active" aria-current="page"> 6 days /7 package</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar & Hero End -->

     <!-- day 6 start -->
     <div class="container-xxl py-5">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s" style="min-height: 400px;">
                    <div class="position-relative h-100">
                        <img class="img-fluid position-absolute w-100 h-100" src="img/zanzibar 2.jpg" alt="" style="object-fit: cover;">
                    </div>
                </div>
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.3s">
                    <h6 class="section-title bg-white text-start text-primary pe-3">Special Packege</h6>
                    <h1 class="mb-4">Our Special <span class="text-primary">Package</span></h1>
                    <p class="mb-4"><h6>DAY 1: TRANSFER TO HOTEL</h6></p>
                    <p class="mb-4">On this day, our driver will meet you at the airport for the transfer to your hotel situated in Paje, The Nest.</p>
                    <p class="mb-4"><h6>DAY 2: FULL DAY SAFARI BLUE TRIP</h6></p>
                    <p class="mb-4">This will be a full day sailing around mangroves and snorkeling along the Menay bay. Sailing to Kwale Island, relaxing at the sandbank, swimming, while you will be enjoying a seafood BBQ and exotic fruits.</p>
                    <p class="mb-4"><h6>DAY 3: TRANSFER TO NUNGWI</h6></p>
                    <p class="mb-4">On this day, after a breakfast, your driver will pick up you to drive you at Nungwi Dream, in Nungwi. And you could relax at the beach or treat yourself to a few hours at the SPA. </p>
                    <p class="mb-4"><h6>DAY 4: SUNSET DOWH CRUISE</h6></p>
                    <p class="mb-4">After spending a relax day on the beach walking between Nungwi and Kendwa, is time to sail again. This time you will enjoy the sunset from the roof of the typical Zanzibarian boat, the Dhow.</p>
                    <p class="mb-4"><h6>DAY 5: TRANSFER TO THE CAPITAL: STONE TOWN</h6></p>
                    <p class="mb-4">On this day your driver will pick up from Nungwi beach ahead to Tembo Beach, Stone town. But before arriving in the city, you will make a stop to visit a spice plantation, and have the opportunity to buy species of all kinds at km 0. </p>
                    <p class="mb-4"><h6>DAY 6: PRISON ISLAND AND STONE TOWN</h6></p>
                    <p class="mb-4">On this day you will land at Prison Island. There you can learn the short history of the prison and take photos with the giant turtles. After you will learn the history & culture of Zanzibar with a local tour guide by visiting most iconic places.</p>
                    <p class="mb-4"><h6>DAY 7: TRANSFER TO THE AIRPORT, GOODBYE!</h6></p>
                    <p class="mb-4">After a week in this beautiful Island, is time for you to take your flight back home. We hope you enjoyed your stay, and brings with you a lot of memories.Safari njema!</p>
                    <a class="btn btn-primary py-3 px-5 mt-2" href="booking.html">Book Now</a>
                </div>
            </div>
        </div>
    </div>
    <!-- day 6 End -->

        

    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Company</h4>
                    <a class="btn btn-link" href="about.php">About Us</a>
                    <a class="btn btn-link" href="contact.php">Contact Us</a>
                    <a class="btn btn-link" href="service.php">Services</a>
                    <a class="btn btn-link" href="package.php">Packages</a>
                    <a class="btn btn-link" href="about.php">FAQs & Help</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Unguja, Zanzibar, Tanzania</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+255 624 656 618</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>PaixprivateTour@gmail.com</p>
                    <div class="d-flex pt-2">
                        <!-- <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/profile.php?id=100089488801328"><i class="fab fa-facebook-f fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/@paixprivatetour"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Gallery</h4>
                    <div class="row g-2 pt-2">
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/hh.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/mnemba 22.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/Safari.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/prison.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/serengeti.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/pree.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Newsletter</h4>
                    <p>Subscribe to our newsletter.</p>
                     <form id="newsletter-form" action="https://formspree.io/f/mjgpdqvo" method="POST" class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-primary w-100 py-3 ps-4 pe-5" type="email" name="email" placeholder="Your email" aria-label="Your email" required>
                        <button type="submit" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">Subscribe</button>
                    </form>
                    <script>
                    document.getElementById('newsletter-form').addEventListener('submit', async function (event) {
                        event.preventDefault();
                        const form = this;
                        const subscribedEmail = form.elements.email.value;
                        const formData = new FormData(form);

                        try {
                            const [emailResponse, databaseResponse] = await Promise.all([
                                fetch(form.action, {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                }),
                                fetch('subribe.php', {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                })
                            ]);

                            const [emailResult, databaseResult] = await Promise.all([
                                emailResponse.json(),
                                databaseResponse.json()
                            ]);

                            if (!emailResponse.ok || emailResult.ok === false || emailResult.success === false) {
                                const formspreeError = emailResult.errors && emailResult.errors[0] && emailResult.errors[0].message;
                                throw new Error(formspreeError || emailResult.message || 'Could not send the subscription email.');
                            }

                            if (!databaseResponse.ok || !databaseResult.success) {
                                throw new Error(databaseResult.message || 'Could not save the subscription to the database.');
                            }

                            Swal.fire({
                                title: 'Data sent successfully',
                                text: `Your subscription email was sent for ${subscribedEmail}.`,
                                icon: 'success'
                            });
                            form.reset();
                        } catch (error) {
                            Swal.fire('Could not subscribe', error.message || 'Please try again later.', 'error');
                        }
                    });
                    </script>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="#">Paixprivate </a>, All Right Reserved.
                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>