<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

require 'db.php';

$fullName = trim($_POST['FullName'] ?? '');
$email = trim($_POST['Email'] ?? '');
$date = trim($_POST['Date'] ?? '');
$destination = trim($_POST['Destination'] ?? '');
$request = trim($_POST['Request'] ?? '');

if ($fullName === '' || $email === '' || $date === '' || $destination === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please complete all required fields']);
    exit;
}

$stmt = $conn->prepare(
    'INSERT INTO bookings (FullName, Email, `Date`, Destination, Request) VALUES (?, ?, ?, ?, ?)'
);

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not prepare booking']);
    exit;
}

$stmt->bind_param('sssss', $fullName, $email, $date, $destination, $request);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'booking_id' => $stmt->insert_id]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not save booking']);
}

$stmt->close();
$conn->close();
?>
 