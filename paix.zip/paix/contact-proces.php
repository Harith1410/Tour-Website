<?php
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$message = trim($_POST['message'] ?? '');
$bookingIdInput = trim($_POST['booking_id'] ?? '');

if ($name === '' || $email === '' || $subject === '' || $message === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Please provide valid values for all required fields']);
    exit;
}

if ($bookingIdInput !== '' && (!ctype_digit($bookingIdInput) || (int) $bookingIdInput < 1)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid booking ID']);
    exit;
}

$bookingId = $bookingIdInput === '' ? null : (int) $bookingIdInput;

try {
    require 'db.php';

    $stmt = $conn->prepare(
        'INSERT INTO contacts (booking_id, name, email, subject, message) VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->bind_param('issss', $bookingId, $name, $email, $subject, $message);
    $stmt->execute();

    echo json_encode(['success' => true, 'contact_id' => $stmt->insert_id]);
    $stmt->close();
    $conn->close();
} catch (Throwable $error) {
    error_log('Contact form database insert failed: ' . $error->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Could not save contact message']);
}
