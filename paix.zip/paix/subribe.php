<?php

header('Content-Type: application/json');

$host = "localhost";
$username = "root";
$password = "";
$database = "paix_tour"; 

// Connect to database
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit;
}

// Check email
if (!isset($_POST['email'])) {
    echo json_encode([
        "success" => false,
        "message" => "Email was not received."
    ]);
    exit;
}

$email = trim($_POST['email']);

// Validate email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        "success" => false,
        "message" => "Invalid email address."
    ]);
    exit;
}

// Check if already subscribed
$sql = "SELECT id FROM subscribers WHERE email = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Prepare error: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {

    echo json_encode([
        "success" => false,
        "message" => "This email is already subscribed."
    ]);

    $stmt->close();
    $conn->close();
    exit;
}

$stmt->close();

// Insert subscriber
$sql = "INSERT INTO subscribers (email) VALUES (?)";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Insert preparation failed: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param("s", $email);

if ($stmt->execute()) {

    echo json_encode([
        "success" => true,
        "message" => "Subscription saved successfully."
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Database error: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();

?>