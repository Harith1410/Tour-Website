<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Pax Tour</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
            <span class="sr-only">Loading...</span>
        </div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <div class="container-fluid bg-dark px-5 d-none d-lg-block">
        <div class="row gx-0">
            <div class="col-lg-8 text-center text-lg-start mb-2 mb-lg-0">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <small class="me-3 text-light"><i class="fa fa-map-marker-alt me-2"></i>Unguja Zanzibar, Tanzania</small>
                    <small class="me-3 text-light"><i class="fa fa-phone-alt me-2"></i>+255 624 656 6618 /+255 773 808 769</small>
                    <small class="text-light"><i class="fa fa-envelope-open me-2"></i>PaixprivateTour@gmail.com</small>
                </div>
            </div>
            <div class="col-lg-4 text-center text-lg-end">
                <div class="d-inline-flex align-items-center" style="height: 45px;">
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.youtube.com/@paixprivatetour" target="_blank"><i class="fab fa-youtube"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.facebook.com/profile.php?id=100089488801328"><i class="fab fa-facebook-f fw-normal"></i></a> 
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                    <a class="btn btn-sm btn-outline-light btn-sm-square rounded-circle me-2" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar & Hero Start -->
    <div class="container-fluid position-relative p-0">
        <nav class="navbar navbar-expand-lg navbar-light px-4 px-lg-5 py-3 py-lg-0">
            <a href="" class="navbar-brand p-0">
                <h1 class="text-primary m-0"><img src="img/h2.png" alt="Logo"></i>Paix Tour</h1>
                
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="fa fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav ms-auto py-0">
                    <a href="index.php" class="nav-item nav-link">Home</a>
                    <a href="about.php" class="nav-item nav-link">About</a>
                    <a href="service.php" class="nav-item nav-link">Services</a>
                    <a href="package.php" class="nav-item nav-link active">Packages</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                        <div class="dropdown-menu m-0">
                            <a href="destination.php" class="dropdown-item">Destination</a>
                            <a href="booking.php" class="dropdown-item">Booking</a>
                            <a href="3 Days.php" class="dropdown-item">3 Days</a>
                            <a href="6 Days.php" class="dropdown-item">6 Days</a>
                            <a href="10 Days.php" class="dropdown-item">10 Days</a>
                        </div>
                    </div>
                    <a href="contact.php" class="nav-item nav-link">Contact</a>
                </div>
                <a href="booking.php" class="btn btn-primary rounded-pill py-2 px-4">Book Now</a>
            </div>
        </nav>

        <div class="container-fluid bg-primary py-5 mb-5 hero-header">
            <div class="container py-5">
                <div class="row justify-content-center py-5">
                    <div class="col-lg-10 pt-lg-5 mt-lg-5 text-center">
                        <h1 class="display-3 text-white animated slideInDown">Packages</h1>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb justify-content-center">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item"><a href="service.php">Service</a></li>
                                <li class="breadcrumb-item text-white active" aria-current="page">Packages</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Navbar & Hero End -->


    <!-- Package Start -->
    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Service</h6>
                <h1 class="mb-5">Our Services</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/hot.jpg" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>Hotels</small>
                        </div>
                        <div class="text-center p-4">
                            <div class="mb-3">
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                            </div>
                            <p>With owned hotels on Unguja Island, better known as Zanzibar, and agreements with almost all the major properties on the island,Paixprivate Tour is able to provide accommodation at all levels, not only Zanzibar but on the whole archipelago and on the Shwaili Coast.</p>
                            <div class="d-flex justify-content-center mb-2">
                                <a href="about.php" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                <a href="booking.php" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/nat 2.jpg" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>Safari</small>
                        </div>
                        <div class="text-center p-4">
                            <div class="mb-3">
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                            </div>
                            <p>Safari in Tanzania means tour through different national parks, to discover wildlife and millennial cultures. Try not to get fascinated by amazing sunsets and endless prairies. Experience the thrill of a close encounter with the Big Fives and much more…
                                Discover it with us!</p>
                            <div class="d-flex justify-content-center mb-2">
                                <a href="about.php" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                <a href="booking.php" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/auric.jpg" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>Transfers and customers care</small>
                            
                        </div>
                        <div class="text-center p-4">
                            <div class="mb-3">
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                                <small class="fa fa-star text-primary"></small>
                            </div>
                            <p>Paix Tour can count on solid local support, which provides an organized transport system from Zanzibar airport or harbor and between several locations and properties all over the island. We can also book domestic flights to reach the main destinations of the archipelago of Zanzibar and the main National Parks of Tanzania</p>
                            <div class="d-flex justify-content-center mb-2">
                                <a href="about.php" class="btn btn-sm btn-primary px-3 border-end" style="border-radius: 30px 0 0 30px;">Read More</a>
                                <a href="booking.php" class="btn btn-sm btn-primary px-3" style="border-radius: 0 30px 30px 0;">Book Now</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Package End -->


    <!-- Booking Start -->
    <div class="container-xxl py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="container">
            <div class="booking p-5">
                <div class="row g-5 align-items-center">
                    <div class="col-md-6 text-white">
                        <h6 class="text-white text-uppercase">Booking</h6>
                        <h1 class="text-white mb-4">Online Booking</h1>
                        <p class="mb-4">From cultural tours that showcase the island's rich history and traditions to outdoor adventures that take you off the beaten path, their tours are designed to provide an unforgettable experience..</p>
                        <p class="mb-4">Led by knowledgeable local guides, you can immerse yourself in the local culture, discover hidden gems, and create lasting memories. Whether you're looking for a relaxing beach holiday or an action packed adventure, Paix of Zanzibar has a tour that will cater to your interests and exceed your expectations.</p>
                    </div>
                   <div class="col-md-6">
                        <h1 class="text-white mb-4">Book Our  Tour</h1>
                        <form action="connection.php" method="POST" id="booking-form">

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="text" class="form-control bg-transparent" id="name" name="FullName" placeholder="Your Name" required>
                                        <label for="name">Full Name</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <input type="email" class="form-control bg-transparent" id="email" name="Email" placeholder="Your Email" required>
                                        <label for="email">Your Email</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating date" id="date3" data-target-input="nearest">
                                        <input type="date" class="form-control bg-transparent datetimepicker-input" id="datetime" name="Date" placeholder="Date & Time" data-target="#date3" data-toggle="datetimepicker" required />
                                        <label for="datetime">Date & Time</label>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-floating">
                                        <select class="form-select bg-transparent" id="select1" name="Destination" required>
                                            <option value="Tanzania">Tanzania</option>
                                            <option value="Zanzibar">Zanzibar</option>
                                        </select>
                                        <label for="select1">Destination</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-floating">
                                        <textarea class="form-control bg-transparent" placeholder="Special Request" id="special_request" name="Request" style="height: 100px"></textarea>
                                        <label for="special_request">Special Request</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button class="btn btn-outline-light w-100 py-3" type="submit">Book Now</button>
                                </div>
                            </div>
                        </form>

                            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
const form = document.getElementById('booking-form');

form.addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default submission

    const formData = new FormData(form);

    // 1️⃣ Send to Formspree (Email)
    const formspreeRequest = fetch('https://formspree.io/f/xljdzkng', {
        method: 'POST',
        body: formData,
        headers: { 'Accept': 'application/json' }
    });

    // 2️⃣ Send to PHP backend (MySQL)
    const phpRequest = fetch('connection.php', {
        method: 'POST',
        body: formData
    });

    // Wait for BOTH requests to finish
    Promise.all([formspreeRequest, phpRequest])
        .then(async ([fsResponse, phpResponse]) => {

            let phpText = await phpResponse.text();

            if (fsResponse.ok && phpResponse.ok) {
                Swal.fire({
                    title: 'Success!',
                    text: 'Booking sent successfully! .',
                    icon: 'success',
                    confirmButtonText: 'OK'
                });
                form.reset();
            } else {
                Swal.fire({
                    title: 'Error!',
                    text: 'There was a problem submitting the form. Please try again.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
                console.log('Formspree:', fsResponse);
                console.log('PHP Response:', phpText);
            }

        })
        .catch(error => {
            Swal.fire({
                title: 'Error!',
                text: 'Network error. Please check your connection.',
                icon: 'error',
                confirmButtonText: 'OK'
            });
            console.error(error);
        });
        });
        </script>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Booking Start -->

     <!-- top activities start -->

    <div class="container-xxl py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h6 class="section-title bg-white text-center text-primary px-3">Top Packeges</h6>
                <h1 class="mb-5">Our Special Packages</h1>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/pree.jpg" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>ZANZIBAR PACKAGE 3 DAYS/2 NIGHT HALF BOARD</small>
                        </div>
                        <div class="text-center p-4">
                            <div class="mb-3">
                            </div>
                            <div class="d-flex justify-content-center mb-2">
                                <a href="3 Days.php" class="btn btn-primary rounded-pill py-2 px-4">Details</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/prison.jpg" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>ZANZIBAR PACKAGE 6DAYS/7 NIGHTS,HALF BOARD</small>
                        </div>
                        <div class="text-center p-4">
                            <div class="d-flex justify-content-center mb-2">
                                <a href="6 Days.php" class="btn btn-primary rounded-pill py-2 px-4">Details</a>
                                 
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                    <div class="package-item">
                        <div class="overflow-hidden">
                            <img class="img-fluid" src="img/zanzibar.png" alt="">
                        </div>
                        <div class="d-flex border-bottom">
                            <small class="flex-fill text-center border-end py-2"><i class="fa fa-map-marker-alt text-primary me-2"></i>ZANZIBAR PACKAGE 10DAYS/9 NIGHTS,HALF BOARD</small>
                            
                        </div>
                        <div class="text-center p-4">
                            
                            <div class="d-flex justify-content-center mb-2">
                                <a href="10 Days.php" class="btn btn-primary rounded-pill py-2 px-4">Details</a>
                                
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- top activities end -->
    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Company</h4>
                    <a class="btn btn-link" href="about.php">About Us</a>
                    <a class="btn btn-link" href="contact.php">Contact Us</a>
                    <a class="btn btn-link" href="service.php">Services</a>
                    <a class="btn btn-link" href="package.php">Packages</a>
                    <a class="btn btn-link" href="about.php">FAQs & Help</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Unguja, Zanzibar, Tanzania</p>
                    <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+255 624 656 618</p>
                    <p class="mb-2"><i class="fa fa-envelope me-3"></i>PaixprivateTour@gmail.com</p>
                    <div class="d-flex pt-2">
                        <!-- <a class="btn btn-outline-light btn-social" href=""><i class="fab fa-twitter"></i></a> -->
                        <a class="btn btn-outline-light btn-social" href="https://www.instagram.com/paix_tours/"><i class="fab fa-instagram fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.facebook.com/profile.php?id=100089488801328"><i class="fab fa-facebook-f fw-normal"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://www.youtube.com/@paixprivatetour"><i class="fab fa-youtube"></i></a>
                        <a class="btn btn-outline-light btn-social" href="https://wa.me/0624656618"><i class="fab fa-whatsapp"></i></a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Gallery</h4>
                    <div class="row g-2 pt-2">
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/hh.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/mnemba 22.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/Safari.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/prison.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/serengeti.jpg" alt="">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light p-1" src="img/pree.jpg" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-white mb-3">Newsletter</h4>
                    <p>Subscribe to our newsletter.</p>
                     <form id="newsletter-form" action="https://formspree.io/f/mjgpdqvo" method="POST" class="position-relative mx-auto" style="max-width: 400px;">
                        <input class="form-control border-primary w-100 py-3 ps-4 pe-5" type="email" name="email" placeholder="Your email" aria-label="Your email" required>
                        <button type="submit" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">Subscribe</button>
                    </form>
                    <script>
                    document.getElementById('newsletter-form').addEventListener('submit', async function (event) {
                        event.preventDefault();
                        const form = this;
                        const subscribedEmail = form.elements.email.value;
                        const formData = new FormData(form);

                        try {
                            const [emailResponse, databaseResponse] = await Promise.all([
                                fetch(form.action, {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                }),
                                fetch('subribe.php', {
                                    method: 'POST',
                                    body: formData,
                                    headers: { 'Accept': 'application/json' }
                                })
                            ]);

                            const [emailResult, databaseResult] = await Promise.all([
                                emailResponse.json(),
                                databaseResponse.json()
                            ]);

                            if (!emailResponse.ok || emailResult.ok === false || emailResult.success === false) {
                                const formspreeError = emailResult.errors && emailResult.errors[0] && emailResult.errors[0].message;
                                throw new Error(formspreeError || emailResult.message || 'Could not send the subscription email.');
                            }

                            if (!databaseResponse.ok || !databaseResult.success) {
                                throw new Error(databaseResult.message || 'Could not save the subscription to the database.');
                            }

                            Swal.fire({
                                title: 'Data sent successfully',
                                text: `Your subscription email was sent for ${subscribedEmail}.`,
                                icon: 'success'
                            });
                            form.reset();
                        } catch (error) {
                            Swal.fire('Could not subscribe', error.message || 'Please try again later.', 'error');
                        }
                    });
                    </script>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                        &copy; <a class="border-bottom" href="">Paix Tour  </a>, All Right Reserved.

                    </div>
                    <div class="col-md-6 text-center text-md-end">
                        <div class="footer-menu">
                            <a href="index.html">Home</a>
                            <a href="">Cookies</a>
                            <a href="">Help</a>
                            <a href="">FQAs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>